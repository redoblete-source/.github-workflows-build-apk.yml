# DocLite v0.1
Visor Android offline y sin anuncios para PDF, DOCX y XLSX.

## Alcance v0.1
- PDF: renderizado de páginas con PdfRenderer de Android.
- DOCX: lectura local de OOXML y visualización de texto/párrafos. Esta primera versión NO garantiza todavía maquetación idéntica de Word.
- XLSX: lectura local de OOXML, hojas y valores de celdas. Esta primera versión NO reproduce todavía todos los estilos/gráficos.
- Sin Internet, sin cuentas, sin anuncios.

## Compilación
Java 17 + Gradle 8.9 + AndroidX. GitHub Actions incluido.
