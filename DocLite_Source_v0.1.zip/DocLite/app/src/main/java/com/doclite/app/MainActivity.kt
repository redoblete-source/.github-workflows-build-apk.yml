package com.doclite.app

import android.app.*
import android.os.*
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.view.*
import android.widget.*
import org.w3c.dom.Element
import java.io.*
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var fileName: TextView
    private lateinit var sheetBar: HorizontalScrollView
    private lateinit var sheetButtons: LinearLayout
    private val picker = 100

    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        content=findViewById(R.id.content); fileName=findViewById(R.id.fileName); sheetBar=findViewById(R.id.sheetBar); sheetButtons=findViewById(R.id.sheetButtons)
        findViewById<Button>(R.id.openBtn).setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="*/*"; putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("application/pdf","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) },picker) }
        if(intent?.action==Intent.ACTION_VIEW) intent.data?.let{ open(it) }
    }
    override fun onActivityResult(r:Int,c:Int,d:Intent?){ super.onActivityResult(r,c,d); if(r==picker&&c==RESULT_OK)d?.data?.let{ open(it) } }
    private fun open(uri:Uri){ content.removeAllViews(); sheetButtons.removeAllViews(); sheetBar.visibility=View.GONE; val n=name(uri); fileName.text=n
        try { when(n.substringAfterLast('.',"").lowercase()){ "pdf"->showPdf(uri); "docx"->showDocx(uri); "xlsx"->showXlsx(uri); else->msg("Formato no compatible todavía") } } catch(e:Exception){ msg("No se pudo abrir: ${e.message}") }
    }
    private fun name(u:Uri):String { contentResolver.query(u,null,null,null,null)?.use{ if(it.moveToFirst()){ val i=it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(i>=0)return it.getString(i)}}; return u.lastPathSegment?:"Documento" }
    private fun msg(s:String){ TextView(this).also{it.text=s;it.textSize=16f;it.setPadding(8,16,8,16);content.addView(it)} }
    private fun showPdf(u:Uri){ val pfd=contentResolver.openFileDescriptor(u,"r")?:return; val renderer=PdfRenderer(pfd)
        for(i in 0 until renderer.pageCount){ val page=renderer.openPage(i); val scale=resources.displayMetrics.widthPixels.toFloat()/page.width; val bmp=Bitmap.createBitmap((page.width*scale).toInt(),(page.height*scale).toInt(),Bitmap.Config.ARGB_8888); bmp.eraseColor(Color.WHITE); page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); ImageView(this).also{it.setImageBitmap(bmp);it.adjustViewBounds=true;content.addView(it)}; page.close() }
        // renderer/pfd retained by rendered bitmaps only for this simple v0.1 viewer
    }
    private fun zipEntries(u:Uri):Map<String,ByteArray>{ val m=mutableMapOf<String,ByteArray>(); ZipInputStream(contentResolver.openInputStream(u)).use{z-> var e=z.nextEntry; while(e!=null){ if(!e.isDirectory){ val out=ByteArrayOutputStream(); z.copyTo(out); m[e.name]=out.toByteArray() }; e=z.nextEntry }}; return m }
    private fun xml(bytes:ByteArray)=DocumentBuilderFactory.newInstance().apply{isNamespaceAware=true}.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
    private fun showDocx(u:Uri){ val z=zipEntries(u); val b=z["word/document.xml"]?:throw Exception("DOCX inválido"); val d=xml(b); val paras=d.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","p")
        for(i in 0 until paras.length){ val p=paras.item(i) as Element; val tv=TextView(this); val sb=StringBuilder(); val texts=p.getElementsByTagNameNS("http://schemas.openxmlformats.org/wordprocessingml/2006/main","t"); for(j in 0 until texts.length) sb.append(texts.item(j).textContent); if(sb.isNotEmpty()){ tv.text=sb.toString(); tv.textSize=16f; tv.setTextColor(Color.BLACK); tv.setPadding(12,5,12,5); content.addView(tv) } }
        if(content.childCount==0)msg("Documento sin texto visible compatible")
    }
    private fun showXlsx(u:Uri){ val z=zipEntries(u); val shared=mutableListOf<String>(); z["xl/sharedStrings.xml"]?.let{ val d=xml(it); val sis=d.getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main","si"); for(i in 0 until sis.length)shared.add(sis.item(i).textContent) }
        val sheets=z.keys.filter{it.matches(Regex("xl/worksheets/sheet\\d+\\.xml"))}.sorted(); if(sheets.isEmpty())throw Exception("XLSX sin hojas")
        sheetBar.visibility=View.VISIBLE
        fun render(path:String){ content.removeAllViews(); val d=xml(z[path]!!); val rows=d.getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main","row"); val table=TableLayout(this); table.setPadding(4,4,4,4)
            for(i in 0 until rows.length){ val tr=TableRow(this); val cells=(rows.item(i) as Element).getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main","c"); for(j in 0 until cells.length){ val c=cells.item(j) as Element; val t=c.getAttribute("t"); val vs=c.getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main","v"); var v=if(vs.length>0)vs.item(0).textContent else ""; if(t=="s")v=v.toIntOrNull()?.let{shared.getOrNull(it)}?:v; TextView(this).also{it.text=v;it.textSize=14f;it.setTextColor(Color.BLACK);it.setPadding(14,10,14,10);it.setBackgroundColor(if(i%2==0)Color.rgb(248,250,252) else Color.WHITE);tr.addView(it)} }; table.addView(tr) }; content.addView(table) }
        sheets.forEachIndexed{i,p-> Button(this).also{it.text="Hoja ${i+1}";it.setOnClickListener{render(p)};sheetButtons.addView(it)} }; render(sheets.first())
    }
}
