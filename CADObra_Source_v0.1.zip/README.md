# CAD Obra v0.1
APK Android de inspección CAD. Funciones actuales: abrir DXF ASCII, zoom por pellizco, pan, ajustar plano, medición entre dos puntos, cota gráfica y observaciones sobre el plano. Incluye plano demo.

Nota: DWG nativo requiere integrar un SDK CAD con licencia; esta compilación muestra un aviso al intentar abrir DWG.
