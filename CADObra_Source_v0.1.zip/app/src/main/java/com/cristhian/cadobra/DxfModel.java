package com.cristhian.cadobra;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import java.util.*;

public class DxfModel {
    public interface Entity { void draw(Canvas c, CadTransform t, Paint p); void bounds(Bounds b); }
    public static class Bounds {
        public double minX=Double.POSITIVE_INFINITY,minY=Double.POSITIVE_INFINITY,maxX=Double.NEGATIVE_INFINITY,maxY=Double.NEGATIVE_INFINITY;
        public void add(double x,double y){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);} 
        public boolean valid(){return Double.isFinite(minX)&&Double.isFinite(minY)&&Double.isFinite(maxX)&&Double.isFinite(maxY);} 
    }
    public static class LineE implements Entity {
        final double x1,y1,x2,y2; LineE(double a,double b,double c,double d){x1=a;y1=b;x2=c;y2=d;}
        public void draw(Canvas c,CadTransform t,Paint p){c.drawLine(t.sx(x1),t.sy(y1),t.sx(x2),t.sy(y2),p);} public void bounds(Bounds b){b.add(x1,y1);b.add(x2,y2);} }
    public static class CircleE implements Entity {
        final double x,y,r; CircleE(double x,double y,double r){this.x=x;this.y=y;this.r=r;}
        public void draw(Canvas c,CadTransform t,Paint p){c.drawCircle(t.sx(x),t.sy(y),(float)(r*t.scale),p);} public void bounds(Bounds b){b.add(x-r,y-r);b.add(x+r,y+r);} }
    public static class ArcE implements Entity {
        final double x,y,r,a0,a1; ArcE(double x,double y,double r,double a0,double a1){this.x=x;this.y=y;this.r=r;this.a0=a0;this.a1=a1;}
        public void draw(Canvas c,CadTransform t,Paint p){float left=t.sx(x-r),right=t.sx(x+r),top=t.sy(y+r),bottom=t.sy(y-r);float sweep=(float)(a1-a0); if(sweep<0)sweep+=360; c.drawArc(left,top,right,bottom,(float)(-a1),sweep,false,p);} public void bounds(Bounds b){b.add(x-r,y-r);b.add(x+r,y+r);} }
    public static class PolyE implements Entity {
        final ArrayList<double[]> pts=new ArrayList<>(); boolean closed=false;
        public void draw(Canvas c,CadTransform t,Paint p){ if(pts.size()<2)return; Path path=new Path(); path.moveTo(t.sx(pts.get(0)[0]),t.sy(pts.get(0)[1])); for(int i=1;i<pts.size();i++)path.lineTo(t.sx(pts.get(i)[0]),t.sy(pts.get(i)[1])); if(closed)path.close(); c.drawPath(path,p);} public void bounds(Bounds b){for(double[] q:pts)b.add(q[0],q[1]);} }
    public static class TextE implements Entity {
        final double x,y,h; final String text; TextE(double x,double y,double h,String s){this.x=x;this.y=y;this.h=h;this.text=s==null?"":s;}
        public void draw(Canvas c,CadTransform t,Paint p){float old=p.getTextSize(); p.setTextSize((float)Math.max(10,h*t.scale)); c.drawText(text,t.sx(x),t.sy(y),p); p.setTextSize(old);} public void bounds(Bounds b){b.add(x,y);} }

    public final ArrayList<Entity> entities = new ArrayList<>();
    public Bounds bounds(){Bounds b=new Bounds(); for(Entity e:entities)e.bounds(b); return b;}
}

class CadTransform {
    double scale=1, tx=0, ty=0;
    float sx(double x){return (float)(x*scale+tx);} float sy(double y){return (float)(-y*scale+ty);} 
    double wx(float x){return (x-tx)/scale;} double wy(float y){return -(y-ty)/scale;}
}
