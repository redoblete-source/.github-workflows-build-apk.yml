package com.cristhian.cadobra;

import java.io.*;import java.util.*;

public class DxfParser {
    static class Pair {int code; String v; Pair(int c,String v){code=c;this.v=v;}}
    static double d(String s,double def){try{return Double.parseDouble(s.trim());}catch(Exception e){return def;}}
    static int i(String s,int def){try{return Integer.parseInt(s.trim());}catch(Exception e){return def;}}

    public static DxfModel parse(InputStream in) throws IOException {
        BufferedReader br=new BufferedReader(new InputStreamReader(in));
        ArrayList<Pair> pairs=new ArrayList<>(); String c,v;
        while((c=br.readLine())!=null && (v=br.readLine())!=null){try{pairs.add(new Pair(Integer.parseInt(c.trim()),v));}catch(Exception ignored){}}
        DxfModel m=new DxfModel(); boolean inEntities=false;
        for(int idx=0;idx<pairs.size();idx++){
            Pair p=pairs.get(idx);
            if(p.code==0 && "SECTION".equals(p.v.trim())){
                if(idx+1<pairs.size() && pairs.get(idx+1).code==2 && "ENTITIES".equalsIgnoreCase(pairs.get(idx+1).v.trim())) inEntities=true;
                continue;
            }
            if(p.code==0 && "ENDSEC".equals(p.v.trim())) {inEntities=false; continue;}
            if(!inEntities || p.code!=0) continue;
            String type=p.v.trim().toUpperCase(Locale.ROOT); int j=idx+1;
            while(j<pairs.size() && pairs.get(j).code!=0) j++;
            List<Pair> e=pairs.subList(idx+1,j);
            if(type.equals("LINE")){
                double x1=0,y1=0,x2=0,y2=0; for(Pair q:e){if(q.code==10)x1=d(q.v,0);else if(q.code==20)y1=d(q.v,0);else if(q.code==11)x2=d(q.v,0);else if(q.code==21)y2=d(q.v,0);} m.entities.add(new DxfModel.LineE(x1,y1,x2,y2));
            } else if(type.equals("CIRCLE")){
                double x=0,y=0,r=0; for(Pair q:e){if(q.code==10)x=d(q.v,0);else if(q.code==20)y=d(q.v,0);else if(q.code==40)r=d(q.v,0);} if(r>0)m.entities.add(new DxfModel.CircleE(x,y,r));
            } else if(type.equals("ARC")){
                double x=0,y=0,r=0,a0=0,a1=0; for(Pair q:e){if(q.code==10)x=d(q.v,0);else if(q.code==20)y=d(q.v,0);else if(q.code==40)r=d(q.v,0);else if(q.code==50)a0=d(q.v,0);else if(q.code==51)a1=d(q.v,0);} if(r>0)m.entities.add(new DxfModel.ArcE(x,y,r,a0,a1));
            } else if(type.equals("LWPOLYLINE")){
                DxfModel.PolyE pe=new DxfModel.PolyE(); double pendingX=Double.NaN; int flags=0;
                for(Pair q:e){if(q.code==70)flags=i(q.v,0); else if(q.code==10)pendingX=d(q.v,0); else if(q.code==20 && !Double.isNaN(pendingX)){pe.pts.add(new double[]{pendingX,d(q.v,0)});pendingX=Double.NaN;}}
                pe.closed=(flags&1)!=0; if(pe.pts.size()>1)m.entities.add(pe);
            } else if(type.equals("TEXT")||type.equals("MTEXT")){
                double x=0,y=0,h=2.5; StringBuilder s=new StringBuilder(); for(Pair q:e){if(q.code==10)x=d(q.v,0);else if(q.code==20)y=d(q.v,0);else if(q.code==40)h=d(q.v,2.5);else if(q.code==1||q.code==3)s.append(q.v.replace("\\P"," "));} m.entities.add(new DxfModel.TextE(x,y,h,s.toString()));
            }
            idx=j-1;
        }
        return m;
    }
}
